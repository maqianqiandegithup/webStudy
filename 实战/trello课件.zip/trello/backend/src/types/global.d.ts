interface UserInfo {
    id: number;
    name: string;
}