<template>
    <div id="notFound">
        <!--头部-->
        <header>
            <div class="left">
                <a href="" class="btn btn-icon">
                    <i class="icon icon-home"></i>
                </a>
                <a href="" class="btn btn-icon">
                    <i class="icon icon-board"></i>
                    <span class="txt">看板</span>
                </a>
            </div>
            <a href="/" class="logo"></a>
            <div class="right">
                <a href="" class="btn btn-icon">
                    <i class="icon icon-add"></i>
                </a>
                <button class="avatar">
                    <span>Z</span>
                </button>
            </div>
        </header>

        <main>

            <h1>页面不存在.</h1>

            <div>
                <a href="register.html">注册</a> | <a href="login.html">登录</a>
            </div>

        </main>
    </div>
</template>