let b = require('./base/b.js')
module.exports = 'b'