<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
@font-face {
    font-family: PINGFANG_REGULAR;
    src: url("./assets/fonts/PINGFANG_REGULAR.ttf");
}
@font-face {
    font-family:PINGFANG_MEDIUM;
    src: url("./assets/fonts/PINGFANG_MEDIUM.ttf");
}
@font-face {
    font-family:PINGFANG_BOLD;
    src: url("./assets/fonts/PINGFANG_BOLD.ttf");
}
</style>
